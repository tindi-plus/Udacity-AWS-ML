from setuptools import setup

setup(name='phem_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['phem_distributions'],
      author='Tindi',
      author_email='myemail@donphemull.com',
      zip_safe=False)
